# Datalab Notebook for Migrating from Cloud Predictions API to Cloud Machine Learning Engine

Taxifare Example Predictions API shows how to create simple regression and classification models to predict taxi fares using Predictions API as well as a few other sample calls.

Taxifare Example Machine Learning Engine shows how to create a simple linear regression model to predict taxi fares using Machine Learning Engine along with Cloud Datalab and Cloud Storage APIs.

The sample data used for this datalab is taken from another taxi fare example and duped here.

[Link goes here]() will be a link to the article explaining the migration once reviewed and completed.
